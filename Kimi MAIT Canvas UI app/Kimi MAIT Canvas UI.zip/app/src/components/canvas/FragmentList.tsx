import { useState } from 'react';
import { motion, AnimatePresence, Reorder } from 'framer-motion';
import { 
  Plus, 
  GripVertical,
  ChevronDown,
  Trash2,
  Copy,
  Bot,
  Sparkles,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  MoreVertical
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCanvasStore, type Fragment, type FragmentKind } from '@/stores/canvasStore';
import { FragmentEditor } from './FragmentEditor';

// Enhanced kind badge colors with gradients
const kindColors: Record<FragmentKind, { bg: string; text: string; border: string; gradient: string; icon: string }> = {
  preamble: { 
    bg: 'bg-gray-500/20', 
    text: 'text-gray-400', 
    border: 'border-gray-500/30',
    gradient: 'from-gray-500/10 to-gray-600/10',
    icon: '📄'
  },
  header: { 
    bg: 'bg-blue-500/20', 
    text: 'text-blue-400', 
    border: 'border-blue-500/30',
    gradient: 'from-blue-500/10 to-blue-600/10',
    icon: '📋'
  },
  question: { 
    bg: 'bg-green-500/20', 
    text: 'text-green-400', 
    border: 'border-green-500/30',
    gradient: 'from-green-500/10 to-green-600/10',
    icon: '❓'
  },
  diagram: { 
    bg: 'bg-purple-500/20', 
    text: 'text-purple-400', 
    border: 'border-purple-500/30',
    gradient: 'from-purple-500/10 to-purple-600/10',
    icon: '📐'
  },
  instruction: { 
    bg: 'bg-orange-500/20', 
    text: 'text-orange-400', 
    border: 'border-orange-500/30',
    gradient: 'from-orange-500/10 to-orange-600/10',
    icon: '📢'
  },
  worked_example: { 
    bg: 'bg-cyan-500/20', 
    text: 'text-cyan-400', 
    border: 'border-cyan-500/30',
    gradient: 'from-cyan-500/10 to-cyan-600/10',
    icon: '💡'
  },
  footer: { 
    bg: 'bg-gray-500/20', 
    text: 'text-gray-400', 
    border: 'border-gray-500/30',
    gradient: 'from-gray-500/10 to-gray-600/10',
    icon: '🏁'
  },
  text_block: { 
    bg: 'bg-yellow-500/20', 
    text: 'text-yellow-400', 
    border: 'border-yellow-500/30',
    gradient: 'from-yellow-500/10 to-yellow-600/10',
    icon: '📝'
  },
};

// Kind labels
const kindLabels: Record<FragmentKind, string> = {
  preamble: 'PREAMBLE',
  header: 'HEADER',
  question: 'QUESTION',
  diagram: 'DIAGRAM',
  instruction: 'INSTRUCTION',
  worked_example: 'WORKED EXAMPLE',
  footer: 'FOOTER',
  text_block: 'TEXT',
};

interface FragmentCardProps {
  fragment: Fragment;
  index: number;
  onMoveUp: () => void;
  onMoveDown: () => void;
  isDragging?: boolean;
}

function FragmentCard({ fragment, index, onMoveUp, onMoveDown, isDragging }: FragmentCardProps) {
  const {
    selectedFragmentId,
    expandedFragmentIds,
    toggleExpanded,
    selectFragment,
    deleteFragment,
    updateFragment,
    setShowRevisionPanel,
    addFragment,
    fragmentOrder,
  } = useCanvasStore();
  
  const [showActions, setShowActions] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [isHidden, setIsHidden] = useState(false);
  
  const isSelected = selectedFragmentId === fragment.id;
  const isExpanded = expandedFragmentIds.has(fragment.id);
  const colors = kindColors[fragment.kind];
  
  // Preview content (first 100 chars)
  const previewContent = fragment.contentLatex
    .replace(/\\[a-zA-Z]+(\[.*?\])?(\{.*?\})?/g, ' ')
    .replace(/\$\$?/g, '')
    .slice(0, 100)
    .trim();
  
  const handleDuplicate = () => {
    addFragment({
      kind: fragment.kind,
      contentLatex: fragment.contentLatex,
      label: `${fragment.label} (Copy)`,
      metadata: fragment.metadata,
    }, fragment.id);
  };
  
  const handleAiEnhance = () => {
    // Mock AI enhancement
    updateFragment(fragment.id, {
      contentLatex: fragment.contentLatex + '\n% AI-enhanced with additional context',
    });
  };
  
  const isFirst = index === 0;
  const isLast = index === fragmentOrder.length - 1;
  
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={{ scale: isDragging ? 1 : 1.005 }}
      className={`rounded-xl border transition-all relative group ${
        isSelected 
          ? `border-mait-cyan/50 shadow-neon-cyan` 
          : 'border-white/10 hover:border-white/20'
      } ${isDragging ? 'shadow-2xl z-50' : ''} ${isHidden ? 'opacity-50' : ''}`}
      style={{
        background: `linear-gradient(135deg, ${colors.bg} 0%, transparent 100%)`,
      }}
    >
      {/* Card Header */}
      <div 
        className="flex items-center gap-2 p-3 cursor-pointer"
        onClick={() => {
          selectFragment(fragment.id);
          toggleExpanded(fragment.id);
        }}
      >
        {/* Drag Handle */}
        <div className="cursor-grab active:cursor-grabbing text-white/30 hover:text-white/60 p-1 rounded hover:bg-white/10">
          <GripVertical className="w-4 h-4" />
        </div>
        
        {/* Kind Icon */}
        <span className="text-lg">{colors.icon}</span>
        
        {/* Kind Badge */}
        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${colors.bg} ${colors.text} border ${colors.border}`}>
          {kindLabels[fragment.kind]}
        </span>
        
        {/* Label */}
        <span className="flex-1 text-white/80 text-sm font-medium truncate">
          {fragment.label}
        </span>
        
        {/* Status Indicators */}
        <div className="flex items-center gap-1">
          {isLocked && <Lock className="w-3 h-3 text-yellow-400" />}
          {isHidden && <EyeOff className="w-3 h-3 text-white/40" />}
        </div>
        
        {/* Marks indicator */}
        {fragment.metadata?.marks && (
          <span className="text-xs text-white/50 bg-white/10 px-2 py-0.5 rounded-full">
            {fragment.metadata.marks}M
          </span>
        )}
        
        {/* Expand/Collapse */}
        <motion.button 
          animate={{ rotate: isExpanded ? 180 : 0 }}
          className="text-white/40 hover:text-white/80 p-1 rounded hover:bg-white/10"
        >
          <ChevronDown className="w-4 h-4" />
        </motion.button>
        
        {/* More Actions */}
        <div className="relative">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowActions(!showActions);
            }}
            className="p-1 rounded hover:bg-white/10 text-white/40 hover:text-white/80"
          >
            <MoreVertical className="w-4 h-4" />
          </button>
          
          <AnimatePresence>
            {showActions && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="absolute right-0 top-full mt-1 p-2 rounded-lg bg-gray-900 border border-white/10 shadow-xl z-50 min-w-[150px]"
              >
                <button
                  onClick={() => {
                    setIsLocked(!isLocked);
                    setShowActions(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded hover:bg-white/10 text-white/70 hover:text-white text-sm"
                >
                  {isLocked ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                  {isLocked ? 'Unlock' : 'Lock'}
                </button>
                <button
                  onClick={() => {
                    setIsHidden(!isHidden);
                    setShowActions(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded hover:bg-white/10 text-white/70 hover:text-white text-sm"
                >
                  {isHidden ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  {isHidden ? 'Show' : 'Hide'}
                </button>
                <div className="h-px bg-white/10 my-1" />
                <button
                  onClick={() => {
                    handleDuplicate();
                    setShowActions(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded hover:bg-white/10 text-white/70 hover:text-white text-sm"
                >
                  <Copy className="w-4 h-4" />
                  Duplicate
                </button>
                <button
                  onClick={() => {
                    deleteFragment(fragment.id);
                    setShowActions(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded hover:bg-red-500/20 text-red-400 hover:text-red-300 text-sm"
                >
                  <Trash2 className="w-4 h-4" />
                  Delete
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
      
      {/* Collapsed Preview */}
      <AnimatePresence>
        {!isExpanded && previewContent && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="px-3 pb-3"
          >
            <p className="text-white/40 text-xs font-mono truncate pl-10">
              {previewContent}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Expanded Content */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="px-3 pb-3 space-y-3">
              {/* Label Editor */}
              <div className="flex items-center gap-2">
                <label className="text-white/40 text-xs w-16">Label</label>
                <input
                  type="text"
                  value={fragment.label}
                  onChange={(e) => updateFragment(fragment.id, { label: e.target.value })}
                  className="flex-1 px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm focus:border-mait-cyan focus:outline-none"
                />
              </div>
              
              {/* Marks & Difficulty (for questions) */}
              {fragment.kind === 'question' && (
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <label className="text-white/40 text-xs">Marks</label>
                    <input
                      type="number"
                      min={1}
                      max={20}
                      value={fragment.metadata?.marks || ''}
                      onChange={(e) => updateFragment(fragment.id, { 
                        metadata: { ...fragment.metadata, marks: parseInt(e.target.value) || 0 }
                      })}
                      className="w-16 px-2 py-1 rounded-lg bg-white/5 border border-white/10 text-white text-sm focus:border-mait-cyan focus:outline-none"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <label className="text-white/40 text-xs">Difficulty</label>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((d) => (
                        <button
                          key={d}
                          onClick={() => updateFragment(fragment.id, {
                            metadata: { ...fragment.metadata, difficulty: d }
                          })}
                          className={`w-6 h-6 rounded text-xs ${
                            (fragment.metadata?.difficulty || 3) >= d
                              ? 'bg-yellow-500/50 text-yellow-400'
                              : 'bg-white/10 text-white/30'
                          }`}
                        >
                          ★
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
              
              {/* LaTeX Editor */}
              <FragmentEditor 
                fragmentId={fragment.id}
                content={fragment.contentLatex}
                onChange={(content) => updateFragment(fragment.id, { contentLatex: content })}
              />
              
              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-2 border-t border-white/10">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowRevisionPanel(true)}
                  className="text-purple-400 hover:text-purple-300 text-xs"
                >
                  <Bot className="w-3 h-3 mr-1" />
                  Revise with AI
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleAiEnhance}
                  className="text-mait-cyan hover:text-mait-cyan/80 text-xs"
                >
                  <Sparkles className="w-3 h-3 mr-1" />
                  Enhance
                </Button>
                
                <div className="flex-1" />
                
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onMoveUp}
                    disabled={isFirst}
                    className="text-white/50 hover:text-white text-xs disabled:opacity-30"
                  >
                    ↑
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onMoveDown}
                    disabled={isLast}
                    className="text-white/50 hover:text-white text-xs disabled:opacity-30"
                  >
                    ↓
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export function FragmentList() {
  const { 
    getOrderedFragments,
    moveFragment,
    setShowInsertMenu,
    fragmentOrder,
    reorderFragment,
  } = useCanvasStore();
  
  const [isReordering, setIsReordering] = useState(false);
  const fragments = getOrderedFragments();
  
  const handleReorder = (newOrder: Fragment[]) => {
    const newOrderIds = newOrder.map(f => f.id);
    // Update the order in the store
    newOrderIds.forEach((id, index) => {
      if (fragmentOrder[index] !== id) {
        reorderFragment(id, index);
      }
    });
  };
  
  if (fragments.length === 0) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex flex-col items-center justify-center h-full text-center p-8"
      >
        <motion.div 
          animate={{ 
            scale: [1, 1.1, 1],
            rotate: [0, 5, -5, 0]
          }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-20 h-20 rounded-2xl bg-gradient-to-br from-mait-cosmic/30 to-mait-cyan/30 flex items-center justify-center mb-6"
        >
          <Plus className="w-10 h-10 text-mait-cyan" />
        </motion.div>
        <h3 className="text-white font-medium text-lg mb-2">No fragments yet</h3>
        <p className="text-white/50 text-sm mb-6 max-w-xs">
          Start building your worksheet by adding fragments from the template library
        </p>
        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          <Button onClick={() => setShowInsertMenu(true)} className="btn-cosmic">
            <Plus className="w-4 h-4 mr-2" />
            Add Fragment
          </Button>
        </motion.div>
      </motion.div>
    );
  }
  
  return (
    <div className="space-y-3">
      {/* Fragment Count & Controls */}
      <div className="flex items-center justify-between">
        <motion.span 
          key={fragments.length}
          initial={{ scale: 1.2, color: '#22d3ee' }}
          animate={{ scale: 1, color: 'rgba(255,255,255,0.5)' }}
          className="text-sm text-white/50"
        >
          {fragments.length} fragment{fragments.length !== 1 ? 's' : ''}
        </motion.span>
        
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsReordering(!isReordering)}
            className={`text-xs px-2 py-1 rounded transition-colors ${
              isReordering ? 'bg-mait-cosmic/30 text-mait-cyan' : 'text-white/50 hover:text-white'
            }`}
          >
            {isReordering ? 'Done' : 'Reorder'}
          </button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowInsertMenu(true)}
            className="text-mait-cyan hover:text-mait-cyan/80"
          >
            <Plus className="w-4 h-4 mr-1" />
            Add
          </Button>
        </div>
      </div>
      
      {/* Fragment Cards - with optional drag reordering */}
      {isReordering ? (
        <Reorder.Group 
          axis="y" 
          values={fragments} 
          onReorder={handleReorder}
          className="space-y-3"
        >
          {fragments.map((fragment) => (
            <Reorder.Item key={fragment.id} value={fragment}>
              <div className="glass-card rounded-xl p-3 flex items-center gap-3 cursor-grab active:cursor-grabbing">
                <GripVertical className="w-4 h-4 text-white/30" />
                <span className="text-lg">{kindColors[fragment.kind].icon}</span>
                <span className="flex-1 text-white/80 text-sm">{fragment.label}</span>
                <span className={`px-2 py-0.5 rounded text-[10px] ${kindColors[fragment.kind].bg} ${kindColors[fragment.kind].text}`}>
                  {kindLabels[fragment.kind]}
                </span>
              </div>
            </Reorder.Item>
          ))}
        </Reorder.Group>
      ) : (
        <div className="space-y-3">
          <AnimatePresence mode="popLayout">
            {fragments.map((fragment, index) => (
              <motion.div
                key={fragment.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: index * 0.05 }}
              >
                <FragmentCard
                  fragment={fragment}
                  index={index}
                  onMoveUp={() => moveFragment(fragment.id, 'up')}
                  onMoveDown={() => moveFragment(fragment.id, 'down')}
                />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
      
      {/* Quick Add Button at Bottom */}
      <motion.button
        onClick={() => setShowInsertMenu(true)}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className="w-full py-3 rounded-xl border border-dashed border-white/20 hover:border-mait-cyan/50 hover:bg-mait-cosmic/10 transition-all flex items-center justify-center gap-2 text-white/50 hover:text-mait-cyan"
      >
        <Plus className="w-4 h-4" />
        <span className="text-sm">Add another fragment</span>
      </motion.button>
    </div>
  );
}
