import { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ChevronDown,
  Type,
  Command,
  FunctionSquare,
  Pi,
  Braces,
  Calculator,
  Sparkles,
  Wand2,
  Check
} from 'lucide-react';

interface FragmentEditorProps {
  fragmentId: string;
  content: string;
  onChange: (content: string) => void;
}

// Enhanced math symbols organized by category
interface SymbolItem {
  label: string;
  command: string;
  cursorOffset?: number;
}

interface SymbolCategory {
  name: string;
  icon: React.ComponentType<{ className?: string }>;
  symbols: SymbolItem[];
}

const symbolCategories: Record<string, SymbolCategory> = {
  math: {
    name: 'Math Symbols',
    icon: Calculator,
    symbols: [
      { label: '×', command: '\\times ' },
      { label: '÷', command: '\\div ' },
      { label: '±', command: '\\pm ' },
      { label: '∓', command: '\\mp ' },
      { label: '∞', command: '\\infty ' },
      { label: '≠', command: '\\neq ' },
      { label: '≤', command: '\\leq ' },
      { label: '≥', command: '\\geq ' },
      { label: '≪', command: '\\ll ' },
      { label: '≫', command: '\\gg ' },
      { label: '∈', command: '\\in ' },
      { label: '∉', command: '\\notin ' },
      { label: '⊂', command: '\\subset ' },
      { label: '⊃', command: '\\supset ' },
      { label: '⊆', command: '\\subseteq ' },
      { label: '⊇', command: '\\supseteq ' },
      { label: '∪', command: '\\cup ' },
      { label: '∩', command: '\\cap ' },
      { label: '∅', command: '\\emptyset ' },
      { label: '∖', command: '\\setminus ' },
      { label: '∀', command: '\\forall ' },
      { label: '∃', command: '\\exists ' },
      { label: '∄', command: '\\nexists ' },
      { label: '∴', command: '\\therefore ' },
      { label: '∵', command: '\\because ' },
      { label: '≈', command: '\\approx ' },
      { label: '≡', command: '\\equiv ' },
      { label: '∼', command: '\\sim ' },
      { label: '≅', command: '\\cong ' },
      { label: '→', command: '\\rightarrow ' },
      { label: '⇒', command: '\\Rightarrow ' },
      { label: '↦', command: '\\mapsto ' },
      { label: '↔', command: '\\leftrightarrow ' },
      { label: '⇔', command: '\\Leftrightarrow ' },
      { label: '↑', command: '\\uparrow ' },
      { label: '↓', command: '\\downarrow ' },
      { label: '∠', command: '\\angle ' },
      { label: '°', command: '^\\circ ' },
      { label: '′', command: "'" },
      { label: '″', command: "''" },
      { label: '…', command: '\\dots ' },
      { label: '⋅', command: '\\cdot ' },
      { label: '∘', command: '\\circ ' },
      { label: '⊕', command: '\\oplus ' },
      { label: '⊗', command: '\\otimes ' },
    ]
  },
  greek: {
    name: 'Greek Letters',
    icon: Pi,
    symbols: [
      { label: 'α', command: '\\alpha ' },
      { label: 'β', command: '\\beta ' },
      { label: 'γ', command: '\\gamma ' },
      { label: 'δ', command: '\\delta ' },
      { label: 'ε', command: '\\epsilon ' },
      { label: 'ζ', command: '\\zeta ' },
      { label: 'η', command: '\\eta ' },
      { label: 'θ', command: '\\theta ' },
      { label: 'ι', command: '\\iota ' },
      { label: 'κ', command: '\\kappa ' },
      { label: 'λ', command: '\\lambda ' },
      { label: 'μ', command: '\\mu ' },
      { label: 'ν', command: '\\nu ' },
      { label: 'ξ', command: '\\xi ' },
      { label: 'π', command: '\\pi ' },
      { label: 'ρ', command: '\\rho ' },
      { label: 'σ', command: '\\sigma ' },
      { label: 'τ', command: '\\tau ' },
      { label: 'φ', command: '\\phi ' },
      { label: 'χ', command: '\\chi ' },
      { label: 'ψ', command: '\\psi ' },
      { label: 'ω', command: '\\omega ' },
      { label: 'Γ', command: '\\Gamma ' },
      { label: 'Δ', command: '\\Delta ' },
      { label: 'Θ', command: '\\Theta ' },
      { label: 'Λ', command: '\\Lambda ' },
      { label: 'Π', command: '\\Pi ' },
      { label: 'Σ', command: '\\Sigma ' },
      { label: 'Φ', command: '\\Phi ' },
      { label: 'Ψ', command: '\\Psi ' },
      { label: 'Ω', command: '\\Omega ' },
      { label: '∇', command: '\\nabla ' },
      { label: '∂', command: '\\partial ' },
    ]
  },
  calculus: {
    name: 'Calculus',
    icon: FunctionSquare,
    symbols: [
      { label: '∫', command: '\\int_{}^{} ', cursorOffset: -5 },
      { label: '∬', command: '\\iint_{}^{} ', cursorOffset: -5 },
      { label: '∭', command: '\\iiint_{}^{} ', cursorOffset: -5 },
      { label: '∮', command: '\\oint_{}^{} ', cursorOffset: -5 },
      { label: '∑', command: '\\sum_{}^{} ', cursorOffset: -5 },
      { label: '∏', command: '\\prod_{}^{} ', cursorOffset: -5 },
      { label: 'lim', command: '\\lim_{} ', cursorOffset: -2 },
      { label: 'd/dx', command: '\\frac{d}{dx} ', cursorOffset: 0 },
      { label: '∂/∂x', command: '\\frac{\\partial}{\\partial x} ', cursorOffset: 0 },
    ]
  },
  structures: {
    name: 'Structures',
    icon: Braces,
    symbols: [
      { label: 'frac', command: '\\frac{}{} ', cursorOffset: -3 },
      { label: 'sqrt', command: '\\sqrt{} ', cursorOffset: -1 },
      { label: 'sqrt[n]', command: '\\sqrt[]{} ', cursorOffset: -2 },
      { label: '^{}', command: '^{} ', cursorOffset: -1 },
      { label: '_{}', command: '_{} ', cursorOffset: -1 },
      { label: '^{}_{}', command: '^{}_{} ', cursorOffset: -4 },
      { label: 'vec', command: '\\vec{} ', cursorOffset: -1 },
      { label: 'hat', command: '\\hat{} ', cursorOffset: -1 },
      { label: 'bar', command: '\\bar{} ', cursorOffset: -1 },
      { label: 'overline', command: '\\overline{} ', cursorOffset: -1 },
      { label: 'underline', command: '\\underline{} ', cursorOffset: -1 },
    ]
  }
};

// LaTeX commands with smart cursor positioning
const latexCommands = [
  { label: '\\frac{}{}', command: '\\frac{}{}', cursorOffset: -3, icon: '÷' },
  { label: '\\sqrt{}', command: '\\sqrt{}', cursorOffset: -1, icon: '√' },
  { label: 'x^{}', command: '^{}', cursorOffset: -1, icon: 'x²' },
  { label: 'x_{}', command: '_{}', cursorOffset: -1, icon: 'x₂' },
  { label: '\\int', command: '\\int_{}^{}', cursorOffset: -5, icon: '∫' },
  { label: '\\sum', command: '\\sum_{}^{}', cursorOffset: -5, icon: '∑' },
  { label: '\\lim', command: '\\lim_{}', cursorOffset: -2, icon: 'lim' },
  { label: '\\infty', command: '\\infty', cursorOffset: 0, icon: '∞' },
];

// Simple LaTeX syntax highlighter
const highlightLatex = (code: string): string => {
  if (!code) return '';
  
  let highlighted = code
    // Escape HTML
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    // Comments
    .replace(/(%.*$)/gm, '<span class="text-green-400/70">$1</span>')
    // LaTeX commands (backslash followed by letters)
    .replace(/(\\[a-zA-Z]+)/g, '<span class="text-purple-400">$1</span>')
    // Braces
    .replace(/(\{|\})/g, '<span class="text-yellow-400">$1</span>')
    // Brackets
    .replace(/(\[|\])/g, '<span class="text-orange-400">$1</span>')
    // Math mode delimiters
    .replace(/(\$\$?)/g, '<span class="text-cyan-400">$1</span>')
    // Numbers
    .replace(/(\d+\.?\d*)/g, '<span class="text-blue-400">$1</span>');
  
  return highlighted;
};

// AI-powered LaTeX suggestions (mock)
const aiSuggestions = [
  { trigger: '\\int', suggestion: '\\int_{a}^{b} f(x) \\, dx' },
  { trigger: '\\frac', suggestion: '\\frac{\\partial f}{\\partial x}' },
  { trigger: '\\sum', suggestion: '\\sum_{i=1}^{n} i^2' },
];

export function FragmentEditor({ content, onChange }: FragmentEditorProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const highlightRef = useRef<HTMLPreElement>(null);
  const [cursorPosition, setCursorPosition] = useState(0);
  const [showSymbolPalette, setShowSymbolPalette] = useState(false);
  const [symbolTab, setSymbolTab] = useState<string>('math');
  const [isSaving, setIsSaving] = useState(false);
  const [showAiSuggestions, setShowAiSuggestions] = useState(false);
  const [lineCount, setLineCount] = useState(1);
  const [scrollTop, setScrollTop] = useState(0);
  
  // Sync scroll between textarea and highlight
  const handleScroll = useCallback(() => {
    if (textareaRef.current && highlightRef.current) {
      highlightRef.current.scrollTop = textareaRef.current.scrollTop;
      highlightRef.current.scrollLeft = textareaRef.current.scrollLeft;
      setScrollTop(textareaRef.current.scrollTop);
    }
  }, []);
  
  // Track cursor position
  const handleSelect = () => {
    if (textareaRef.current) {
      setCursorPosition(textareaRef.current.selectionStart);
      
      // Check for AI suggestions
      const beforeCursor = content.slice(0, textareaRef.current.selectionStart);
      const lastWord = beforeCursor.split(/\s/).pop() || '';
      const hasSuggestion = aiSuggestions.some(s => lastWord.includes(s.trigger));
      setShowAiSuggestions(hasSuggestion);
    }
  };
  
  // Insert command at cursor
  const insertCommand = (command: string, cursorOffset: number = 0) => {
    const before = content.slice(0, cursorPosition);
    const after = content.slice(cursorPosition);
    const newContent = before + command + after;
    onChange(newContent);
    
    setTimeout(() => {
      if (textareaRef.current) {
        const newPosition = cursorPosition + command.length + cursorOffset;
        textareaRef.current.setSelectionRange(newPosition, newPosition);
        textareaRef.current.focus();
        setCursorPosition(newPosition);
      }
    }, 0);
  };
  
  // Auto-save indicator
  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onChange(e.target.value);
    setLineCount(e.target.value.split('\n').length);
    setIsSaving(true);
    setTimeout(() => setIsSaving(false), 500);
  };
  
  // Apply AI suggestion
  const applyAiSuggestion = (suggestion: string) => {
    const before = content.slice(0, cursorPosition);
    const after = content.slice(cursorPosition);
    const lastWordIndex = before.lastIndexOf('\\');
    const newContent = before.slice(0, lastWordIndex) + suggestion + after;
    onChange(newContent);
    setShowAiSuggestions(false);
  };
  
  // Format LaTeX (basic prettify)
  const formatLatex = () => {
    let formatted = content
      .replace(/\\begin\{/g, '\n\\begin{')
      .replace(/\\end\{/g, '\n\\end{')
      .replace(/\\\\/g, '\\\\\n')
      .replace(/\n\n\n+/g, '\n\n');
    onChange(formatted.trim());
  };
  
  return (
    <div className="space-y-2">
      {/* Enhanced Toolbar */}
      <div className="flex flex-wrap items-center gap-1 p-2 rounded-lg bg-white/5">
        {/* Quick Commands */}
        <div className="flex items-center gap-1">
          {latexCommands.slice(0, 4).map((cmd) => (
            <motion.button
              key={cmd.label}
              onClick={() => insertCommand(cmd.command, cmd.cursorOffset)}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              className="px-2 py-1.5 rounded hover:bg-white/10 text-white/60 hover:text-white transition-colors text-xs font-mono"
              title={cmd.label}
            >
              {cmd.icon}
            </motion.button>
          ))}
        </div>
        
        <div className="w-px h-5 bg-white/20 mx-1" />
        
        {/* More Commands Dropdown */}
        <div className="relative group">
          <button className="flex items-center gap-1 px-2 py-1.5 rounded hover:bg-white/10 text-white/60 hover:text-white text-xs">
            <Command className="w-3 h-3" />
            More
            <ChevronDown className="w-3 h-3" />
          </button>
          <div className="absolute top-full left-0 mt-1 p-2 rounded-lg bg-gray-900 border border-white/10 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50 min-w-[150px]">
            {latexCommands.slice(4).map((cmd) => (
              <button
                key={cmd.label}
                onClick={() => insertCommand(cmd.command, cmd.cursorOffset)}
                className="w-full text-left px-2 py-1 rounded hover:bg-white/10 text-white/60 hover:text-white text-xs"
              >
                {cmd.icon} {cmd.label}
              </button>
            ))}
          </div>
        </div>
        
        <div className="w-px h-5 bg-white/20 mx-1" />
        
        {/* Delimiters */}
        {[
          { label: '$...$', cmd: '$$', off: -1 },
          { label: '$$...$$', cmd: '$$$$', off: -2 },
          { label: '( )', cmd: '\\left( \\right)', off: -9 },
          { label: '[ ]', cmd: '\\left[ \\right]', off: -9 },
          { label: '{ }', cmd: '\\left\\{ \\right\\}', off: -10 },
        ].map((d) => (
          <motion.button
            key={d.label}
            onClick={() => insertCommand(d.cmd, d.off)}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className="px-2 py-1.5 rounded hover:bg-white/10 text-white/60 hover:text-white text-xs font-mono"
          >
            {d.label}
          </motion.button>
        ))}
        
        <div className="w-px h-5 bg-white/20 mx-1" />
        
        {/* Symbol Palette Toggle */}
        <motion.button
          onClick={() => setShowSymbolPalette(!showSymbolPalette)}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className={`flex items-center gap-1 px-2 py-1.5 rounded text-xs transition-colors ${
            showSymbolPalette ? 'bg-mait-cosmic/30 text-mait-cyan' : 'text-white/60 hover:text-white hover:bg-white/10'
          }`}
        >
          <Type className="w-3 h-3" />
          Symbols
          <ChevronDown className={`w-3 h-3 transition-transform ${showSymbolPalette ? 'rotate-180' : ''}`} />
        </motion.button>
        
        <div className="flex-1" />
        
        {/* Format Button */}
        <motion.button
          onClick={formatLatex}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-1 px-2 py-1.5 rounded hover:bg-white/10 text-white/60 hover:text-white text-xs"
          title="Format LaTeX"
        >
          <Sparkles className="w-3 h-3" />
          Format
        </motion.button>
      </div>
      
      {/* Enhanced Symbol Palette */}
      <AnimatePresence>
        {showSymbolPalette && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="p-3 rounded-lg bg-gray-900/80 border border-white/10">
              {/* Category Tabs */}
              <div className="flex gap-1 mb-3">
                {(Object.keys(symbolCategories) as Array<keyof typeof symbolCategories>).map((cat) => {
                  const Icon = symbolCategories[cat].icon;
                  return (
                    <button
                      key={cat}
                      onClick={() => setSymbolTab(cat)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs transition-all ${
                        symbolTab === cat 
                          ? 'bg-mait-cosmic/30 text-mait-cyan border border-mait-cosmic/30' 
                          : 'text-white/50 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <Icon className="w-3 h-3" />
                      {symbolCategories[cat].name}
                    </button>
                  );
                })}
              </div>
              
              {/* Symbols Grid */}
              <div className="grid grid-cols-8 sm:grid-cols-12 gap-1">
                {symbolCategories[symbolTab].symbols.map((sym: SymbolItem, idx: number) => (
                  <motion.button
                    key={sym.label}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: idx * 0.01 }}
                    onClick={() => insertCommand(sym.command, sym.cursorOffset ?? 0)}
                    whileHover={{ scale: 1.15, backgroundColor: 'rgba(255,255,255,0.15)' }}
                    whileTap={{ scale: 0.9 }}
                    className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white/80 hover:text-white text-sm font-mono transition-all"
                    title={sym.command}
                  >
                    {sym.label}
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* AI Suggestions */}
      <AnimatePresence>
        {showAiSuggestions && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-2 rounded-lg bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/30"
          >
            <div className="flex items-center gap-2 mb-2">
              <Wand2 className="w-4 h-4 text-purple-400" />
              <span className="text-xs text-purple-400 font-medium">AI Suggestions</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {aiSuggestions.map((s) => (
                <button
                  key={s.trigger}
                  onClick={() => applyAiSuggestion(s.suggestion)}
                  className="px-2 py-1 rounded bg-white/10 hover:bg-white/20 text-white/70 hover:text-white text-xs font-mono transition-colors"
                >
                  {s.suggestion}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Editor with Syntax Highlighting */}
      <div className="relative">
        {/* Line Numbers */}
        <div className="absolute left-0 top-0 bottom-0 w-10 bg-black/20 rounded-l-lg border-r border-white/5 overflow-hidden">
          <div 
            className="py-3 text-right pr-2 text-xs text-white/30 font-mono select-none"
            style={{ transform: `translateY(-${scrollTop}px)` }}
          >
            {Array.from({ length: Math.max(lineCount, 10) }, (_, i) => (
              <div key={i + 1} className="h-5 leading-5">{i + 1}</div>
            ))}
          </div>
        </div>
        
        {/* Highlight Layer */}
        <pre
          ref={highlightRef}
          className="absolute left-10 right-0 top-0 bottom-0 m-0 p-3 font-mono text-sm bg-transparent text-transparent pointer-events-none overflow-auto whitespace-pre-wrap break-all z-10"
          aria-hidden="true"
        >
          <code 
            className="block min-h-full"
            dangerouslySetInnerHTML={{ 
              __html: highlightLatex(content) || '<span class="text-white/20">Enter LaTeX content...</span>' 
            }}
          />
        </pre>
        
        {/* Textarea */}
        <textarea
          ref={textareaRef}
          value={content}
          onChange={handleChange}
          onSelect={handleSelect}
          onKeyUp={handleSelect}
          onClick={handleSelect}
          onScroll={handleScroll}
          placeholder="Enter LaTeX content..."
          className="w-full h-48 pl-12 pr-4 py-3 rounded-lg bg-black/30 border border-white/10 text-white/90 font-mono text-sm resize-y focus:border-mait-cyan focus:outline-none transition-colors whitespace-pre-wrap"
          spellCheck={false}
          style={{ tabSize: 2 }}
        />
        
        {/* Status Bar */}
        <div className="absolute bottom-0 left-0 right-0 h-6 bg-black/50 rounded-b-lg border-t border-white/5 flex items-center justify-between px-3 text-[10px]">
          <div className="flex items-center gap-3 text-white/40">
            <span>{lineCount} lines</span>
            <span>{content.length} chars</span>
            <span>UTF-8</span>
          </div>
          <div className="flex items-center gap-2">
            {isSaving ? (
              <span className="text-yellow-400/70 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-yellow-400 animate-pulse" />
                Saving...
              </span>
            ) : (
              <span className="text-green-400/70 flex items-center gap-1">
                <Check className="w-3 h-3" />
                Saved
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
