import { useEffect, useState, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FileText, 
  AlertCircle,
  CheckCircle2,
  Loader2,
  Download,
  Save,
  Eye,
  History,
  ChevronUp,
  ChevronDown,
  Maximize2,
  Keyboard,
  Check,
  X,
  Copy,
  Terminal,
  Settings2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCanvasStore, createDocumentFromWorksheet } from '@/stores/canvasStore';
import { FragmentList } from './FragmentList';
import { PdfPreviewPane } from './PdfPreviewPane';
import { CanvasToolbar } from './CanvasToolbar';
import { InsertFragmentMenu } from './InsertFragmentMenu';
import { ScanQuestionModal } from './ScanQuestionModal';
import { RevisionPanel } from './RevisionPanel';
import { RevisionTimeline } from './RevisionTimeline';
import { CompileErrorBanner } from './CompileErrorBanner';

interface InlineCanvasProps {
  config: {
    yearLevel: string;
    subject: string;
    topics: string[];
    questionCount: number;
    difficulty: number;
  };
  onExpand?: () => void;
}

// Mock compilation service
const mockCompile = async (latexSource: string): Promise<{ success: boolean; pdfUrl?: string; error?: string }> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      if (latexSource.includes('\\documentclass')) {
        resolve({ 
          success: true, 
          pdfUrl: 'data:application/pdf;base64,JVBERi0xLjQKJcOkw7zDtsO...'
        });
      } else {
        resolve({ 
          success: false, 
          error: '! LaTeX Error: Missing \\documentclass command.' 
        });
      }
    }, 2000);
  });
};

const mockHumanizeError = async (_error: string): Promise<string> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve("There's a missing command in your document. Make sure you have a proper LaTeX preamble with \\documentclass.");
    }, 500);
  });
};

// Keyboard shortcuts
const keyboardShortcuts = [
  { key: 'Ctrl + Shift + P', action: 'Compile & Preview' },
  { key: 'Ctrl + S', action: 'Save document' },
  { key: 'Ctrl + Z', action: 'Undo' },
  { key: 'Ctrl + Shift + Z', action: 'Redo' },
  { key: 'Ctrl + F', action: 'Find in document' },
  { key: 'Ctrl + /', action: 'Toggle comment' },
  { key: 'Tab', action: 'Insert 2 spaces' },
  { key: 'Shift + Tab', action: 'Remove 2 spaces' },
];

export function InlineCanvas({ config, onExpand }: InlineCanvasProps) {
  const [showRevisionTimeline, setShowRevisionTimeline] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [isExpanded, setIsExpanded] = useState(true);
  const [isInitialized, setIsInitialized] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [autoCompile, setAutoCompile] = useState(false);
  const [compileDelay, setCompileDelay] = useState(2000);
  const [showLatexSource, setShowLatexSource] = useState(false);
  const compileTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  
  const {
    document: doc,
    fragmentsById,
    fragmentOrder,
    activeBuild,
    isCompiling,
    setDocument,
    setFragments,
    setActiveBuild,
    setIsCompiling,
    getOrderedFragments,
    setShowInsertMenu,
    setShowScanModal,
    setShowRevisionPanel,
    showRevisionPanel,
  } = useCanvasStore();

  // Initialize document from config
  useEffect(() => {
    if (!isInitialized && config) {
      const { document: newDoc, fragments } = createDocumentFromWorksheet(config);
      setDocument(newDoc);
      setFragments(fragments);
      setIsInitialized(true);
      setLastSaved(new Date());
    }
  }, [config, isInitialized, setDocument, setFragments]);

  // Track unsaved changes and auto-save
  useEffect(() => {
    if (doc) {
      setHasUnsavedChanges(true);
      const timer = setTimeout(() => {
        setHasUnsavedChanges(false);
        setLastSaved(new Date());
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [fragmentsById, fragmentOrder, doc]);

  // Auto-compile when content changes
  useEffect(() => {
    if (autoCompile && !isCompiling) {
      if (compileTimeoutRef.current) {
        clearTimeout(compileTimeoutRef.current);
      }
      compileTimeoutRef.current = setTimeout(() => {
        handleCompile();
      }, compileDelay);
    }
    return () => {
      if (compileTimeoutRef.current) {
        clearTimeout(compileTimeoutRef.current);
      }
    };
  }, [fragmentsById, fragmentOrder, autoCompile]);

  const assembleLatex = useCallback(() => {
    const fragments = getOrderedFragments();
    return fragments.map((f) => f.contentLatex).join('\n\n');
  }, [getOrderedFragments]);

  const handleCompile = async () => {
    setIsCompiling(true);
    setActiveBuild(null);
    
    const latexSource = assembleLatex();
    
    const buildId = `build_${Date.now()}`;
    setActiveBuild({
      id: buildId,
      documentId: doc?.id || '',
      status: 'compiling',
      createdAt: new Date().toISOString(),
    });
    
    const result = await mockCompile(latexSource);
    
    if (result.success) {
      setActiveBuild({
        id: buildId,
        documentId: doc?.id || '',
        status: 'success',
        pdfUrl: result.pdfUrl,
        createdAt: new Date().toISOString(),
        completedAt: new Date().toISOString(),
      });
    } else {
      const humanizedError = await mockHumanizeError(result.error || '');
      setActiveBuild({
        id: buildId,
        documentId: doc?.id || '',
        status: 'failed',
        errorMessage: result.error,
        errorMessageHuman: humanizedError,
        createdAt: new Date().toISOString(),
        completedAt: new Date().toISOString(),
      });
    }
    
    setIsCompiling(false);
  };

  const handleSave = () => {
    setHasUnsavedChanges(false);
    setLastSaved(new Date());
    // In a real app, this would save to the backend
  };

  const handleExport = (format: 'pdf' | 'tex') => {
    if (format === 'tex') {
      const latex = assembleLatex();
      const blob = new Blob([latex], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${doc?.title || 'worksheet'}.tex`;
      a.click();
      URL.revokeObjectURL(url);
    } else if (format === 'pdf' && activeBuild?.pdfUrl) {
      const a = document.createElement('a');
      a.href = activeBuild.pdfUrl;
      a.download = `${doc?.title || 'worksheet'}.pdf`;
      a.click();
    }
  };

  const copyLatexSource = () => {
    navigator.clipboard.writeText(assembleLatex());
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'P') {
        e.preventDefault();
        handleCompile();
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        handleSave();
      }
      if ((e.ctrlKey || e.metaKey) && e.key === '?') {
        e.preventDefault();
        setShowShortcuts(true);
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleCompile]);

  if (!doc) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="flex items-center gap-3">
          <Loader2 className="w-6 h-6 text-mait-cyan animate-spin" />
          <span className="text-white/60">Initializing Canvas...</span>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-card-strong rounded-2xl overflow-hidden"
    >
      {/* Header */}
      <div className="border-b border-white/10 px-4 py-3 flex items-center justify-between bg-white/5">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-mait-cosmic to-mait-cyan flex items-center justify-center">
              <FileText className="w-4 h-4 text-white" />
            </div>
            <div>
              <h2 className="text-white font-medium text-sm sm:text-base">
                {doc?.title || 'Untitled Worksheet'}
              </h2>
              <div className="flex items-center gap-2">
                {hasUnsavedChanges ? (
                  <span className="text-xs text-yellow-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-yellow-400 animate-pulse" />
                    Unsaved changes
                  </span>
                ) : lastSaved ? (
                  <span className="text-xs text-green-400 flex items-center gap-1">
                    <Check className="w-3 h-3" />
                    Saved {lastSaved.toLocaleTimeString()}
                  </span>
                ) : null}
              </div>
            </div>
          </div>
          
          {/* Build Status */}
          <div className="hidden sm:flex items-center gap-2">
            {isCompiling && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-2 px-3 py-1 rounded-full bg-yellow-500/20 text-yellow-400 text-sm"
              >
                <Loader2 className="w-4 h-4 animate-spin" />
                Compiling...
              </motion.div>
            )}
            {activeBuild?.status === 'success' && !isCompiling && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-2 px-3 py-1 rounded-full bg-green-500/20 text-green-400 text-sm"
              >
                <CheckCircle2 className="w-4 h-4" />
                Compiled
              </motion.div>
            )}
            {activeBuild?.status === 'failed' && !isCompiling && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/20 text-red-400 text-sm"
              >
                <AlertCircle className="w-4 h-4" />
                Error
              </motion.div>
            )}
          </div>
        </div>
        
        {/* Actions */}
        <div className="flex items-center gap-1">
          {/* Settings */}
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowSettings(!showSettings)}
              className="text-white/60 hover:text-white hidden md:flex"
            >
              <Settings2 className="w-4 h-4" />
            </Button>
            
            <AnimatePresence>
              {showSettings && (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  className="absolute right-0 top-full mt-2 p-4 rounded-xl bg-gray-900 border border-white/10 shadow-xl z-50 w-64"
                >
                  <h4 className="text-white font-medium mb-3">Canvas Settings</h4>
                  
                  <div className="space-y-3">
                    <label className="flex items-center justify-between cursor-pointer">
                      <span className="text-white/70 text-sm">Auto-compile</span>
                      <button
                        onClick={() => setAutoCompile(!autoCompile)}
                        className={`w-10 h-5 rounded-full transition-colors ${
                          autoCompile ? 'bg-mait-cyan' : 'bg-white/20'
                        }`}
                      >
                        <motion.div
                          animate={{ x: autoCompile ? 20 : 2 }}
                          className="w-4 h-4 rounded-full bg-white"
                        />
                      </button>
                    </label>
                    
                    {autoCompile && (
                      <div>
                        <span className="text-white/50 text-xs">Delay: {compileDelay}ms</span>
                        <input
                          type="range"
                          min={500}
                          max={5000}
                          step={500}
                          value={compileDelay}
                          onChange={(e) => setCompileDelay(Number(e.target.value))}
                          className="w-full mt-1"
                        />
                      </div>
                    )}
                    
                    <div className="h-px bg-white/10" />
                    
                    <button
                      onClick={() => {
                        setShowLatexSource(!showLatexSource);
                        setShowSettings(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded hover:bg-white/10 text-white/70 hover:text-white text-sm"
                    >
                      <Terminal className="w-4 h-4" />
                      View LaTeX Source
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowRevisionTimeline(!showRevisionTimeline)}
            className="hidden md:flex text-white/60 hover:text-white"
          >
            <History className="w-4 h-4 mr-1" />
            <span className="hidden lg:inline">History</span>
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={handleSave}
            className="text-white/60 hover:text-white"
          >
            <Save className="w-4 h-4 mr-1" />
            <span className="hidden sm:inline">Save</span>
          </Button>
          
          <div className="h-6 w-px bg-white/20 hidden sm:block" />
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleExport('tex')}
            className="hidden sm:flex btn-glass"
          >
            <Terminal className="w-4 h-4 mr-1" />
            .tex
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleExport('pdf')}
            disabled={!activeBuild?.pdfUrl}
            className="hidden sm:flex btn-glass"
          >
            <Download className="w-4 h-4 mr-1" />
            .pdf
          </Button>
          
          <Button
            onClick={handleCompile}
            disabled={isCompiling}
            className="btn-cosmic"
          >
            {isCompiling ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <Eye className="w-4 h-4 mr-1" />
                <span className="hidden sm:inline">Preview</span>
              </>
            )}
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowShortcuts(true)}
            className="text-white/60 hover:text-white hidden lg:flex"
          >
            <Keyboard className="w-4 h-4" />
          </Button>
          
          {onExpand && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onExpand}
              className="text-white/60 hover:text-white hidden xl:flex"
            >
              <Maximize2 className="w-4 h-4" />
            </Button>
          )}
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-white/60 hover:text-white"
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </Button>
        </div>
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            {/* Toolbar */}
            <CanvasToolbar 
              onInsert={() => setShowInsertMenu(true)}
              onScan={() => setShowScanModal(true)}
              onToggleRevision={() => setShowRevisionPanel(!showRevisionPanel)}
              showRevision={showRevisionPanel}
            />

            {/* LaTeX Source View */}
            <AnimatePresence>
              {showLatexSource && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="border-b border-white/10 bg-black/50"
                >
                  <div className="flex items-center justify-between px-4 py-2 border-b border-white/10">
                    <span className="text-white/60 text-sm flex items-center gap-2">
                      <Terminal className="w-4 h-4" />
                      Generated LaTeX Source
                    </span>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={copyLatexSource}
                        className="text-white/60 hover:text-white"
                      >
                        <Copy className="w-4 h-4 mr-1" />
                        Copy
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowLatexSource(false)}
                        className="text-white/60 hover:text-white"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  <pre className="p-4 text-xs font-mono text-white/70 overflow-auto max-h-[200px] custom-scrollbar">
                    {assembleLatex()}
                  </pre>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Main Content - Side by Side */}
            <div className="flex flex-col lg:flex-row" style={{ minHeight: '600px', maxHeight: '800px' }}>
              {/* Left Pane - Fragment List */}
              <div className="w-full lg:w-1/2 flex flex-col border-b lg:border-b-0 lg:border-r border-white/10">
                {/* Error Banner */}
                <CompileErrorBanner />
                
                {/* Fragment List */}
                <div className="flex-1 overflow-y-auto custom-scrollbar p-4">
                  <FragmentList />
                </div>
                
                {/* Mobile Preview Button */}
                <div className="lg:hidden p-4 border-t border-white/10">
                  <Button
                    onClick={handleCompile}
                    disabled={isCompiling}
                    className="w-full btn-cosmic"
                  >
                    {isCompiling ? (
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    ) : (
                      <Eye className="w-4 h-4 mr-2" />
                    )}
                    Preview PDF
                  </Button>
                </div>
              </div>
              
              {/* Right Pane - PDF Preview */}
              <div className="hidden lg:flex flex-1 flex-col">
                <PdfPreviewPane 
                  pdfUrl={activeBuild?.pdfUrl}
                  isCompiling={isCompiling}
                />
              </div>
              
              {/* Revision Panel - Overlay */}
              <AnimatePresence>
                {showRevisionPanel && (
                  <motion.div
                    initial={{ x: 300, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    exit={{ x: 300, opacity: 0 }}
                    className="absolute right-0 top-[180px] bottom-0 w-80 glass-card-strong border-l border-white/10 z-40"
                  >
                    <RevisionPanel />
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Keyboard Shortcut Hint */}
            <div className="px-4 py-2 border-t border-white/10 bg-white/5 flex items-center justify-between">
              <div className="flex items-center gap-4 text-xs text-white/30">
                <span className="flex items-center gap-1">
                  <kbd className="px-1.5 py-0.5 rounded bg-white/10">Ctrl</kbd>
                  <kbd className="px-1.5 py-0.5 rounded bg-white/10">Shift</kbd>
                  <kbd className="px-1.5 py-0.5 rounded bg-white/10">P</kbd>
                  to Preview
                </span>
                <span className="flex items-center gap-1">
                  <kbd className="px-1.5 py-0.5 rounded bg-white/10">Ctrl</kbd>
                  <kbd className="px-1.5 py-0.5 rounded bg-white/10">S</kbd>
                  to Save
                </span>
                <span className="hidden md:flex items-center gap-1">
                  <kbd className="px-1.5 py-0.5 rounded bg-white/10">Ctrl</kbd>
                  <kbd className="px-1.5 py-0.5 rounded bg-white/10">?</kbd>
                  for shortcuts
                </span>
              </div>
              <span className="text-xs text-white/30">
                {fragmentOrder.length} fragments
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Modals */}
      <InsertFragmentMenu />
      <ScanQuestionModal />
      
      {/* Revision Timeline Drawer */}
      <RevisionTimeline 
        isOpen={showRevisionTimeline}
        onClose={() => setShowRevisionTimeline(false)}
      />

      {/* Keyboard Shortcuts Modal */}
      <AnimatePresence>
        {showShortcuts && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm"
            onClick={() => setShowShortcuts(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="glass-card-strong rounded-2xl p-6 max-w-md w-full mx-4"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Keyboard className="w-5 h-5 text-mait-cyan" />
                  Keyboard Shortcuts
                </h3>
                <button
                  onClick={() => setShowShortcuts(false)}
                  className="p-2 rounded-lg hover:bg-white/10 text-white/60 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="space-y-2">
                {keyboardShortcuts.map(({ key, action }) => (
                  <div
                    key={key}
                    className="flex items-center justify-between p-3 rounded-lg bg-white/5"
                  >
                    <span className="text-white/70 text-sm">{action}</span>
                    <kbd className="px-2 py-1 rounded bg-white/10 text-white/80 text-sm font-mono">
                      {key}
                    </kbd>
                  </div>
                ))}
              </div>
              
              <p className="mt-4 text-xs text-white/40 text-center">
                Press <kbd className="px-1 rounded bg-white/10">Ctrl</kbd> + <kbd className="px-1 rounded bg-white/10">?</kbd> to show this dialog
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
